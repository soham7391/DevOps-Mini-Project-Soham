# Git Workflow Simulator

This project demonstrates a professional Git workflow.

## Workflow

1. Create feature branch
2. Develop feature
3. Commit changes
4. Create Pull Request
5. Review code
6. Merge to main
7. Create release tag

## Branches

- main
- feature-login
- feature-dashboard

## Release

v1.0.0
