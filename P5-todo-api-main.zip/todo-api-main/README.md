# Dockerized To-Do API

## Description

This project demonstrates how to containerize a Flask REST API using Docker.

## Features

- Flask-based REST API
- Docker containerization
- JSON responses
- To-Do task endpoint

## API Endpoints

### Home

```text
/
```

Response:

```json
{"message":"Todo API Running"}
```

### Todos

```text
/todos
```

Response:

```json
[
  {"id":1,"task":"Learn Docker"},
  {"id":2,"task":"Complete DevOps Mini Project"}
]
```

## Technologies Used

- Python
- Flask
- Docker
- Git
- GitHub

## Run Locally

```bash
pip install -r requirements.txt
python app.py
```

## Run with Docker

```bash
docker build -t todo-api .
docker run -d -p 5000:5000 --name todo-container todo-api
```

## Output

Access:

```text
http://localhost:5000
```

and

```text
http://localhost:5000/todos
```
