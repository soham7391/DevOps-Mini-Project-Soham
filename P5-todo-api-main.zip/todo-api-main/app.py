from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return jsonify({"message": "Todo API Running"})

@app.route("/todos")
def todos():
    return jsonify([
        {"id": 1, "task": "Learn Docker"},
        {"id": 2, "task": "Complete DevOps Mini Project"}
    ])

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
