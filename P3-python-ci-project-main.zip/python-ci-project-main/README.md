# Python CI Pipeline

This project demonstrates Continuous Integration using GitHub Actions.

## Features

- Python application
- Unit testing using pytest
- Linting using flake8
- Automated CI pipeline

## Workflow

Every push triggers:

1. Dependency installation
2. Code linting
3. Unit tests
4. Build status reporting
