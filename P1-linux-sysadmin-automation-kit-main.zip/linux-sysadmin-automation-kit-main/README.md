# Linux Sysadmin Automation Kit

## Description

This project automates server health monitoring using Bash scripting.

## Features

- Disk usage monitoring
- Memory usage monitoring
- Running services monitoring
- Log generation

## Run

```bash
chmod +x health_check.sh
./health_check.sh
```

## Output

Generated inside:

```text
report.log
```
