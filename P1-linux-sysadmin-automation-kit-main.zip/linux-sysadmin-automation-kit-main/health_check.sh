#!/bin/bash

echo "=================================" > report.log
echo "SERVER HEALTH REPORT" >> report.log
echo "=================================" >> report.log

date >> report.log

echo "" >> report.log
echo "DISK USAGE" >> report.log
df -h >> report.log

echo "" >> report.log
echo "MEMORY USAGE" >> report.log
free -h >> report.log

echo "" >> report.log
echo "RUNNING SERVICES" >> report.log

if command -v systemctl &> /dev/null
then
    systemctl list-units --type=service --state=running >> report.log
else
    echo "systemctl not available" >> report.log
fi

echo "" >> report.log
echo "Health report generated successfully."
